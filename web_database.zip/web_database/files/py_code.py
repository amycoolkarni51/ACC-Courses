array = ['Hello', 'World']
print(array)