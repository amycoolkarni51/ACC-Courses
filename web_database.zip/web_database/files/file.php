<?php
    echo "Hello, World!";
?>
    