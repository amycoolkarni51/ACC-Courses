public class JavaProgram {
    public static void main(String[] args) {
        // Write your code here
        System.out.println("Hello World!");
    }
}
