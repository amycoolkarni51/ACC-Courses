from django.apps import AppConfig


class JavacompilerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'javacompiler'
